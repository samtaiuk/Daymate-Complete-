# DayMate Android Project — Grid + Settings Update

This is the complete Android Studio/Gradle source project for DayMate. It includes the green-and-white three-column home grid, separate Settings screen, phone tone picker, Android DND/notification/exact-alarm settings shortcuts, calendar app shortcut, wake-up alarm, daily itinerary, water reminder, event reminder, routine-call reminder, sleep reminder, and one-hour gaming-break timer.

## Important limitations
- This source project has not been compiled or tested in this packaging step. Build it before installing the new APK.
- Calendar currently opens the phone calendar app; automatic two-way calendar synchronisation is not implemented.
- Android does not generally allow an ordinary app to force-stop another app for game limits.
- DND changes require the user to grant Android notification-policy access.
- Android notification channels can retain prior sound settings; changing tone may require managing/recreating notification channels in Android settings.
- The water reminder currently schedules the next reminder, not an indefinitely repeating series.
- The app stores routine entries and preferences locally on the device.

## Build APK using GitHub Actions on a phone
1. Extract this ZIP on your phone.
2. Upload the contents of the `DayMate` folder to your GitHub repository, keeping the folder contents at the repository root (so `settings.gradle`, `build.gradle`, `app/`, and `.github/` are at the root).
3. Open the repository on GitHub, select **Actions**, choose **Build DayMate APK**, and tap **Run workflow** (or push a commit to `main`).
4. Open the completed workflow run, scroll to **Artifacts**, and download `DayMate-debug-apk`.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`. Install it only after backing up the currently working APK/data as appropriate.

Package: `com.daymate.app`
