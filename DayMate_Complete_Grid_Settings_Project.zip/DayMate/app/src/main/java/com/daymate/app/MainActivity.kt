package com.daymate.app

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.media.RingtoneManager
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val green = 0xFF238636.toInt()
    private val darkGreen = 0xFF176B35.toInt()
    private val pageColor = 0xFFF4FAF4.toInt()
    private lateinit var p: android.content.SharedPreferences
    private lateinit var list: LinearLayout
    private var showingSettings = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("daymate", 0)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != 0) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        renderHome()
    }

    private fun baseScreen(title: String, subtitle: String, settingsButton: Boolean) {
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            setBackgroundColor(pageColor)
        }
        scroll.addView(list)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(TextView(this).apply {
            text = title
            textSize = 28f
            setTextColor(darkGreen)
            setTypeface(null, 1)
        })
        titleBox.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(0xFF5E6F60.toInt())
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        if (settingsButton) {
            header.addView(Button(this).apply {
                text = "☰"
                textSize = 20f
                contentDescription = "Open settings menu"
                setOnClickListener { renderSettings() }
            })
        } else {
            header.addView(Button(this).apply {
                text = "← Home"
                setOnClickListener { renderHome() }
            })
        }
        list.addView(header)
        list.addView(View(this).apply { minimumHeight = dp(14) })
    }

    private fun renderHome() {
        showingSettings = false
        baseScreen("DayMate", "Your day, planned with purpose.", true)

        val features = listOf(
            Feature("📅", "Calendar") { openCalendar() },
            Feature("⏰", "Wake-up\nalarm") { setupWakeAlarm() },
            Feature("☑️", "Daily\nitinerary") { setupItinerary() },
            Feature("💧", "Drink\nwater") { setupWater() },
            Feature("🌙", "Sleep\nreminder") { setupBedtime() },
            Feature("＋", "Event") { setupEvent() },
            Feature("☎️", "Routine\ncalls") { setupCalls() },
            Feature("🎮", "Game\nlimit") { setupGaming() },
            Feature("⚙️", "Settings") { renderSettings() }
        )
        features.chunked(3).forEach { rowFeatures ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowFeatures.forEach { feature ->
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(5), dp(12), dp(5), dp(10))
                    setBackgroundColor(0xFFFFFFFF.toInt())
                    isClickable = true
                    isFocusable = true
                    setOnClickListener { feature.action() }
                    elevation = dp(2).toFloat()
                }
                tile.addView(TextView(this).apply {
                    text = feature.icon
                    textSize = 27f
                    gravity = Gravity.CENTER
                })
                tile.addView(TextView(this).apply {
                    text = feature.title
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTextColor(darkGreen)
                    setTypeface(null, 1)
                    setPadding(0, dp(6), 0, 0)
                })
                val lp = LinearLayout.LayoutParams(0, dp(112), 1f)
                lp.setMargins(dp(4), dp(4), dp(4), dp(8))
                row.addView(tile, lp)
            }
            while (row.childCount < 3) {
                row.addView(View(this), LinearLayout.LayoutParams(0, dp(112), 1f).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(8))
                })
            }
            list.addView(row)
        }

        val items = p.getString("items", "")!!.split("\n").filter { it.isNotBlank() }
        if (items.isNotEmpty()) {
            list.addView(label("Today's itinerary"))
            items.forEachIndexed { idx, item ->
                list.addView(TextView(this).apply {
                    text = item.replace("|", "  •  ")
                    setPadding(dp(10), dp(12), dp(10), dp(12))
                    setBackgroundColor(0xFFFFFFFF.toInt())
                    setOnLongClickListener {
                        val updated = items.toMutableList()
                        updated.removeAt(idx)
                        p.edit().putString("items", updated.joinToString("\n")).apply()
                        renderHome()
                        true
                    }
                })
            }
            list.addView(TextView(this).apply {
                text = "Tip: long-press an itinerary item to remove it."
                textSize = 11f
                setTextColor(0xFF5E6F60.toInt())
            })
        }
        list.addView(TextView(this).apply {
            text = "Offline by design • Your routine is stored on this phone."
            textSize = 12f
            setTextColor(0xFF5E6F60.toInt())
            setPadding(0, dp(16), 0, 0)
        })
    }

    private data class Feature(val icon: String, val title: String, val action: () -> Unit)

    private fun renderSettings() {
        showingSettings = true
        baseScreen("Settings", "Manage DayMate and phone integration.", false)
        settingsItem("🔔  Phone tones", "Choose alarm and reminder sounds") { chooseTone() }
        settingsItem("🌙  Do Not Disturb / Bedtime", "Open Android access settings") { openDndSettings() }
        settingsItem("📅  Calendar synchronisation", "Open your phone calendar") { openCalendar() }
        settingsItem("🔔  Notifications", "Manage DayMate notifications") { openAppNotificationSettings() }
        settingsItem("⏰  Alarm and exact reminders", "Review Android alarm settings") { openAlarmSettings() }
        settingsItem("🔐  App permissions", "Review permissions for DayMate") { openAppSettings() }
        settingsItem("ℹ️  About DayMate", "Offline routine planner") {
            AlertDialog.Builder(this).setTitle("About DayMate")
                .setMessage("DayMate helps you manage routines, alarms, water reminders, events and daily calls. Your routine data is stored locally on this phone.")
                .setPositiveButton("OK", null).show()
        }
    }

    private fun settingsItem(title: String, subtitle: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            elevation = dp(1).toFloat()
        }
        box.addView(label(title))
        box.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(0xFF5E6F60.toInt())
        })
        list.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun setupWakeAlarm() {
        val t = field("Time HH:MM")
        t.setText(p.getString("wake", "06:30"))
        dialog("Wake-up alarm", t) {
            parse(t.text.toString())?.let {
                p.edit().putString("wake", t.text.toString()).apply()
                daily(10, it.first, it.second, "Good morning", "Time to wake up.", true)
            } ?: toast("Use HH:MM")
        }
    }

    private fun setupItinerary() {
        val box = LinearLayout(this).apply { orientation = 1 }
        val a = field("Start time")
        val b = field("Activity")
        val c = field("Remarks")
        val d = field("End time")
        listOf(a, b, c, d).forEach { box.addView(it) }
        dialog("Add activity", box) {
            if (b.text.isNotBlank()) {
                val items = p.getString("items", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
                items.add("${a.text}|${b.text}|${c.text}|${d.text}")
                p.edit().putString("items", items.joinToString("\n")).apply()
                renderHome()
            } else toast("Enter activity")
        }
    }

    private fun setupWater() {
        val t = field("Interval minutes, 15–240")
        t.setText(p.getInt("water_interval", 60).toString())
        dialog("Water reminder", t) {
            val n = t.text.toString().toIntOrNull()
            if (n != null && n in 15..240) {
                p.edit().putInt("water_interval", n).apply()
                water(n)
                toast("Water reminder started")
            } else toast("Choose 15–240 minutes")
        }
    }

    private fun setupEvent() {
        val box = LinearLayout(this).apply { orientation = 1 }
        val a = field("Event name")
        val b = field("Date YYYY-MM-DD")
        val c = field("Time HH:MM")
        listOf(a, b, c).forEach { box.addView(it) }
        dialog("Event reminder", box) {
            try {
                val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { isLenient = false }
                    .parse("${b.text} ${c.text}")!!
                if (date.time <= System.currentTimeMillis()) throw Exception()
                ReminderScheduler.schedule(this, (System.currentTimeMillis() % 99999).toInt(), date.time,
                    a.text.toString().ifBlank { "Event" }, "Your event is due.")
                toast("Event scheduled")
            } catch (e: Exception) { toast("Check date and time") }
        }
    }

    private fun setupCalls() {
        val box = LinearLayout(this).apply { orientation = 1 }
        val a = field("Person to call")
        val b = field("Time HH:MM")
        box.addView(a); box.addView(b)
        dialog("Routine call", box) {
            parse(b.text.toString())?.let {
                daily((System.currentTimeMillis() % 99999).toInt(), it.first, it.second,
                    "Routine call", "Remember to call ${a.text}")
            } ?: toast("Use HH:MM")
        }
    }

    private fun setupGaming() {
        AlertDialog.Builder(this).setTitle("Gaming limit")
            .setMessage("Start a one-hour timer. Android generally does not allow DayMate to force-stop another app, so this will notify you to take a break.")
            .setPositiveButton("Start timer") { _, _ ->
                ReminderScheduler.schedule(this, 301, System.currentTimeMillis() + 3600000,
                    "Gaming break", "One hour is up. Take a break.")
                toast("Timer started")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun setupBedtime() {
        val t = field("Time HH:MM")
        t.setText(p.getString("bedtime", "22:00"))
        dialog("Sleep reminder", t) {
            parse(t.text.toString())?.let {
                p.edit().putString("bedtime", t.text.toString()).apply()
                daily(40, it.first, it.second, "Time to sleep", "Would you like to enable Do Not Disturb?")
                AlertDialog.Builder(this).setTitle("Enable sleep mode?")
                    .setMessage("Android requires you to grant Do Not Disturb access before an app can change it.")
                    .setPositiveButton("Open DND settings") { _, _ -> openDndSettings() }
                    .setNegativeButton("Later", null).show()
            } ?: toast("Use HH:MM")
        }
    }

    private fun chooseTone() {
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_NOTIFICATION)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose DayMate alarm/reminder tone")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            p.getString("tone_uri", null)?.let { putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it)) }
        }
        try { startActivityForResult(intent, 501) }
        catch (e: Exception) { toast("Tone picker is not available on this phone") }
    }

    @Deprecated("Android tone picker result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 501 && resultCode == RESULT_OK) {
            val uri: Uri? = data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            p.edit().putString("tone_uri", uri?.toString()).apply()
            toast(if (uri == null) "Silent tone selected" else "Tone saved for DayMate")
        }
    }

    private fun openCalendar() {
        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR),
            Intent(Intent.ACTION_INSERT).setData(android.provider.CalendarContract.Events.CONTENT_URI)
        )
        for (intent in intents) {
            try { startActivity(intent); return } catch (_: Exception) { }
        }
        toast("No calendar app found on this phone")
    }

    private fun openDndSettings() {
        try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        catch (e: Exception) { toast("Open Android Settings and search for Do Not Disturb access") }
    }

    private fun openAppNotificationSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= 26) Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            startActivity(intent)
        } catch (e: Exception) { openAppSettings() }
    }

    private fun openAlarmSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: Exception) { openAppSettings() }
    }

    private fun openAppSettings() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        catch (e: Exception) { toast("Open Android Settings to manage app permissions") }
    }

    private fun daily(id: Int, h: Int, m: Int, title: String, msg: String, wake: Boolean = false) {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        ReminderScheduler.schedule(this, id, c.timeInMillis, title, msg, wake)
        toast("Reminder scheduled")
    }

    private fun water(mins: Int) {
        ReminderScheduler.schedule(this, 200, System.currentTimeMillis() + mins * 60000L,
            "Drink water", "Take a moment to drink water.")
    }

    private fun card(title: String, sub: String, act: () -> Unit) {
        val v = LinearLayout(this).apply { orientation = 1; setPadding(dp(13), dp(12), dp(13), dp(12)); setBackgroundColor(-1) }
        v.addView(label(title))
        v.addView(TextView(this).apply { text = sub; setTextColor(0xFF5E6F60.toInt()) })
        v.addView(Button(this).apply { text = "Set up"; setOnClickListener { act() } })
        list.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 16f; setTextColor(green); setTypeface(null, 1); setPadding(0, dp(4), 0, dp(7))
    }
    private fun field(h: String) = EditText(this).apply { hint = h; setSingleLine() }
    private fun dialog(t: String, v: View, save: () -> Unit) {
        AlertDialog.Builder(this).setTitle(t).setView(v).setPositiveButton("Save") { _, _ -> save() }
            .setNegativeButton("Cancel", null).show()
    }
    private fun parse(s: String): Pair<Int, Int>? {
        val a = s.trim().split(":")
        val h = a.getOrNull(0)?.toIntOrNull(); val m = a.getOrNull(1)?.toIntOrNull()
        return if (h != null && m != null && h in 0..23 && m in 0..59) h to m else null
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
