package com.daymate.app

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val prefs = c.getSharedPreferences("daymate", 0)
        val selectedTone = prefs.getString("tone_uri", null)?.let { Uri.parse(it) }
        val tone = selectedTone ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        // Use a tone-specific channel ID so Android can apply a newly selected tone.
        val channelId = "daymate_reminders_" + (tone?.toString()?.hashCode() ?: 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (nm.getNotificationChannel(channelId) == null) {
                val channel = NotificationChannel(
                    channelId,
                    "DayMate reminders",
                    NotificationManager.IMPORTANCE_HIGH
                )
                channel.setSound(
                    tone,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                nm.createNotificationChannel(channel)
            }
        }

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(c, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(c).setSound(tone)
        }

        builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(i.getStringExtra("title") ?: "DayMate reminder")
            .setContentText(i.getStringExtra("message") ?: "It's time.")
            .setAutoCancel(true)

        nm.notify(i.getIntExtra("id", 1001), builder.build())

        if (i.getBooleanExtra("wake", false) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (prefs.getBoolean("restore_dnd", true) && nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            }
        }
    }
}

object ReminderScheduler {
    fun schedule(
        c: Context,
        id: Int,
        at: Long,
        title: String,
        msg: String,
        wake: Boolean = false
    ) {
        val intent = Intent(c, ReminderReceiver::class.java)
            .putExtra("id", id)
            .putExtra("title", title)
            .putExtra("message", msg)
            .putExtra("wake", wake)

        val pending = PendingIntent.getBroadcast(
            c,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        } else {
            alarm.setExact(AlarmManager.RTC_WAKEUP, at, pending)
        }
    }
}
