package com.daymate.app

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val prefs = c.getSharedPreferences("daymate", 0)
        val dndAction = i.getStringExtra("dnd_action")
        if (dndAction == "yes") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm.isNotificationPolicyAccessGranted) {
                prefs.edit().putInt("previous_interruption_filter", nm.currentInterruptionFilter).putBoolean("dnd_changed_by_daymate", true).apply()
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            } else {
                val open = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { c.startActivity(open) } catch (_: Exception) { }
            }
            return
        }
        if (dndAction == "no") return

        val selectedTone = prefs.getString("tone_uri", null)?.let { Uri.parse(it) }
        val tone = selectedTone ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val channelId = "daymate_reminders_" + (tone?.toString()?.hashCode() ?: 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(channelId) == null) {
            val channel = NotificationChannel(channelId, "DayMate reminders", NotificationManager.IMPORTANCE_HIGH)
            channel.setSound(tone, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            nm.createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(c, channelId) else {
            @Suppress("DEPRECATION")
            Notification.Builder(c).setSound(tone)
        }
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(i.getStringExtra("title") ?: "DayMate reminder")
            .setContentText(i.getStringExtra("message") ?: "It's time.")
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(Notification.PRIORITY_MAX)

        if (i.getBooleanExtra("sleep", false)) {
            val yesIntent = Intent(c, ReminderReceiver::class.java).putExtra("dnd_action", "yes")
            val noIntent = Intent(c, ReminderReceiver::class.java).putExtra("dnd_action", "no")
            val yesPi = PendingIntent.getBroadcast(c, 8801, yesIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val noPi = PendingIntent.getBroadcast(c, 8802, noIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            builder.addAction(android.R.drawable.ic_lock_idle_alarm, "Enable DND", yesPi)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "No", noPi)
            if (prefs.getBoolean("sleep_dnd_enabled", false) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm.isNotificationPolicyAccessGranted) {
                prefs.edit().putInt("previous_interruption_filter", nm.currentInterruptionFilter).putBoolean("dnd_changed_by_daymate", true).apply()
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            }
        }
        if (i.getBooleanExtra("wake", false)) {
            val launch = Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val fullScreen = PendingIntent.getActivity(c, 8803, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            builder.setFullScreenIntent(fullScreen, true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm.isNotificationPolicyAccessGranted && prefs.getBoolean("dnd_changed_by_daymate", false)) {
                val previous = prefs.getInt("previous_interruption_filter", NotificationManager.INTERRUPTION_FILTER_ALL)
                nm.setInterruptionFilter(previous)
                prefs.edit().putBoolean("dnd_changed_by_daymate", false).apply()
            }
        }
        nm.notify(i.getIntExtra("id", 1001), builder.build())
    }
}

object ReminderScheduler {
    fun schedule(c: Context, id: Int, at: Long, title: String, msg: String, wake: Boolean = false, sleep: Boolean = false) {
        val intent = Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("title", title)
            .putExtra("message", msg).putExtra("wake", wake).putExtra("sleep", sleep)
        val pending = PendingIntent.getBroadcast(c, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        } else alarm.setExact(AlarmManager.RTC_WAKEUP, at, pending)
    }
}
