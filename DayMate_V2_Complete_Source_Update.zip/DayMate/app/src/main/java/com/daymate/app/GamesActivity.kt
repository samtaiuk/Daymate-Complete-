package com.daymate.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Button
import android.widget.TextView
import android.graphics.Color

class GamesActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(244,250,244)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8,8,8,8) }
        bar.addView(Button(this).apply { text = "← DayMate"; setOnClickListener { finish() } })
        bar.addView(TextView(this).apply { text = "  DayMate Games"; textSize = 20f; setTextColor(Color.rgb(23,107,53)); gravity = android.view.Gravity.CENTER_VERTICAL })
        root.addView(bar)
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme == "https" && uri.host != "appassets.androidplatform.net" && uri.host != "localhost") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)); return true } catch (_: Exception) { }
                }
                return false
            }
        }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        web.loadUrl("file:///android_asset/games.html" + if (intent.getStringExtra("section") == "music") "#music" else "")
    }
}
