# DayMate Android Source — Version 2 Feature Update

This ZIP contains the Android source project plus the requested feature additions. It is intended to be opened in GitHub or Android build tooling and built into a new APK.

## Included

- Existing DayMate green-and-white routine app, settings, phone-tone selection, calendar shortcut, water/event reminders and wake-up alarm.
- Sleep reminder with Yes/No choice for DND at bedtime. DND access must be granted in Android Settings. When DayMate changes DND, the wake-up reminder attempts to restore the previous interruption filter.
- Routine Calls contact picker.
- Itinerary records with date, start time, activity, completion status, remarks and actual end time. Existing older saved itinerary rows are still readable.
- Productivity summary for this week, month and year based on locally stored itinerary entries.
- Local bundled game hub with Snake, 2048, Tic-tac-toe, Brick breaker and a lightweight two-player chess board.
- Online game links for third-party multiplayer/racing games, plus online music service links. These providers require internet and control their own accounts, availability and playback.
- One-hour gaming-break reminder.
- High-priority reminder notification and full-screen-intent request for wake-up alarm where Android allows it.
- GitHub Actions workflow to build a debug APK with Java 17 and Gradle 8.9.

## Important limitations

- This source bundle has not been compiled in this environment because Gradle/Android SDK are unavailable here. Run the included GitHub Actions workflow and inspect the build result before installing.
- Android may restrict full-screen notifications, exact alarms and DND changes. Grant the relevant special access in Android Settings. No app can guarantee it will appear over every app on every Android version.
- The chess game is a lightweight local two-player version with basic movement validation; it does not implement every official chess rule (including castling, en passant and complete check/checkmate detection).
- Online multiplayer and racing are provider links, not a DayMate-hosted multiplayer server. Online music opens third-party services; no copyrighted music is bundled.
- The 60-minute feature is a reminder timer; Android does not allow ordinary apps to forcibly stop every other game without additional privileged permissions.
- Productivity summaries are stored on the phone and use the activity records saved in DayMate. They are not cloud-synchronised.

## Build using GitHub on Android

1. Keep a backup of your currently working ZIP/repository.
2. Upload/extract the project into your existing repository, or copy the changed files into the same paths. Preserve the `com.daymate.app` package and existing workflow.
3. Commit to a separate branch first, then use GitHub Actions → Build DayMate APK → Run workflow.
4. Wait for the workflow to finish. If it fails, open the failed step and use the exact error text to troubleshoot.
5. Download the `DayMate-debug-apk` artifact and test alarms, DND access, contacts, itinerary, games, online links and reports on your phone.

The source ZIP is not itself an APK. A new APK must be built from it.
